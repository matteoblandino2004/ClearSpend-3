// ============================================================
// ClearSpend — state.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   1. STATE & STORAGE
   ----------------------------------------------------------------
   "state" is the single object that holds ALL of the user's data.
   Anything the user enters gets stored in here, then saveState()
   writes the whole object to the browser's localStorage as JSON.
   loadState() does the reverse when the page opens.

   Because everything lives in localStorage:
     - Data is private to each person's own browser/device
     - Nothing is sent to any server
     - Clearing browser data will erase it
   ================================================================ */

// The key under which we store everything in localStorage.
// If you ever make a breaking change to the state "shape",
// bump this version number (e.g. 'clearspend_v4') so old,
// incompatible data doesn't cause errors for returning users.
const STORAGE_KEY = 'clearspend_v3';

let state = {
  // ---- Income ----
  income: 0,              // dollar amount PER PAYCHECK (or per month if frequency = monthly)
  incomeFreq: 'monthly',  // 'monthly' | 'weekly' | 'biweekly'
  payMode: 'average',     // how to count paychecks per month: 'average' | 'pattern' | 'manual'
  payAnchorDate: '',      // for payMode 'pattern': one known real pay date (YYYY-MM-DD)
  payManualDates: [],     // for payMode 'manual': array of "YYYY-MM-DD" strings the user added

  // ---- Budgeting data ----
  expenses: [],   // fixed monthly bills: [{ id, name, amt }]
  cards: [],      // credit/debit cards: [{ id, name, type, limit, apr, due, balance }]
  purchases: [],  // logged transactions: [{ id, amt, cardId, cardName, cardType, cat, note, date }]
  goals: [],      // savings goals: [{ id, name, target, saved, date }]

  // ---- Calendar view state (which month is currently shown) ----
  calYear: new Date().getFullYear(),
  calMonth: new Date().getMonth()
};

// Write the current `state` object to localStorage as a JSON string.
// Called after every add/edit/delete so nothing is lost on refresh.
function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    // localStorage can fail if it's full or disabled (private browsing, etc.)
    console.warn('save failed', e);
  }
}

// Read saved data from localStorage (if any) and merge it into `state`.
// Uses {...state, ...loaded} so that if we ever ADD new fields to the
// default `state` object above, old saved data won't be missing them
// (the defaults fill in any gaps).
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const loaded = JSON.parse(raw);
      state = {
        ...state,
        ...loaded,
        calYear: loaded.calYear || new Date().getFullYear(),
        calMonth: loaded.calMonth != null ? loaded.calMonth : new Date().getMonth(),
        payManualDates: loaded.payManualDates || []
      };
    }
  } catch (e) {
    console.warn('load failed', e);
  }
}


/* ================================================================
   2. HELPERS
   ----------------------------------------------------------------
   Small reusable functions used across multiple screens.
   ================================================================ */

// Format a number as US currency, e.g. fmt(1234.5) -> "$1,234.50"
// Negative numbers get a leading "-" and the rest is shown as positive.
function fmt(n) {
  const abs = Math.abs(n);
  const str = abs.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (n < 0 ? '-' : '') + '$' + str;
}

// Return all purchases that fall within a given month/year.
function getMonthPurchases(year, month) {
  return state.purchases.filter(p => {
    const d = new Date(p.date + 'T00:00:00'); // T00:00:00 avoids timezone shift bugs
    return d.getFullYear() === year && d.getMonth() === month;
  });
}

// Return all purchases logged on one specific date ("YYYY-MM-DD").
function getDayPurchases(dateStr) {
  return state.purchases.filter(p => p.date === dateStr);
}

// Return the small HTML "chip" used to show a card's network (VISA, MC, etc.)
function getNetTag(type) {
  const cls = { visa:'net-visa', mastercard:'net-mastercard', amex:'net-amex', debit:'net-debit', discover:'net-discover', other:'net-other' };
  const lbl = { visa:'VISA', mastercard:'MC', amex:'AMEX', debit:'DEBIT', discover:'DISC', other:'CARD' };
  return `<span class="net-tag ${cls[type] || 'net-other'}">${lbl[type] || 'CARD'}</span>`;
}


/* ================================================================
   3. PAY SCHEDULE LOGIC  (the "available balance" fix)
   ----------------------------------------------------------------
   PROBLEM THIS SOLVES:
   If you're paid $1,500 biweekly, the old app multiplied that by
   2.17 (the average number of biweekly paychecks per month over a
   full year: 26 paychecks / 12 months = 2.1667) to get ~$3,250/mo.

   That average is mathematically correct ACROSS A WHOLE YEAR, but
   in any SINGLE month it's often wrong — most months only have 2
   biweekly paychecks, not 2.17. So the app showed more money
   available than the person actually had that month.

   THE FIX — three modes the user can choose from:

     "average"  - keep the old simple-average behavior (now clearly
                  labeled so the user knows it's an estimate)

     "pattern"  - user gives ONE real pay date they know (an "anchor").
                  We then step forward/backward by 7 days (weekly) or
                  14 days (biweekly) to figure out every other pay
                  date, and count how many land in the month being
                  viewed. This handles "every other Friday" perfectly.

     "manual"   - user just types in the exact dates they get paid,
                  month by month. Most flexible, good for irregular
                  schedules (e.g. self-employed, irregular shifts).
   ================================================================ */

// Returns an array of "YYYY-MM-DD" strings — the pay dates that fall
// inside the given month, according to the user's chosen pay mode.
function getPayDatesInMonth(year, month) {
  // Monthly income isn't really "paydates" in the same sense —
  // just return a placeholder single date for display purposes.
  if (state.incomeFreq === 'monthly') {
    return [`${year}-${String(month + 1).padStart(2, '0')}-01`];
  }

  // ---- MANUAL MODE ----
  // The user typed in exact dates. Just filter to the ones in this month.
  if (state.payMode === 'manual') {
    return state.payManualDates.filter(ds => {
      const d = new Date(ds + 'T00:00:00');
      return d.getFullYear() === year && d.getMonth() === month;
    });
  }

  // ---- PATTERN MODE ----
  // The user gave us one known pay date (the "anchor"). Step forward
  // or backward from it by the pay interval (7 or 14 days) until we
  // cover the target month, collecting every date that lands inside it.
  if (state.payMode === 'pattern' && state.payAnchorDate) {
    const intervalDays = state.incomeFreq === 'weekly' ? 7 : 14;
    const anchor = new Date(state.payAnchorDate + 'T00:00:00');
    const targetStart = new Date(year, month, 1);       // first day of target month
    const targetEnd = new Date(year, month + 1, 0);     // last day of target month

    const dates = [];

    if (anchor <= targetEnd) {
      // The anchor date is on or before the target month — step FORWARD.
      let cursor = new Date(anchor);

      // Skip ahead in big jumps until we're close to the target month,
      // so we don't loop thousands of times for far-future months.
      while (cursor < targetStart) {
        const next = new Date(cursor);
        next.setDate(next.getDate() + intervalDays);
        if (next > targetEnd) break; // would overshoot — stop fast-forwarding
        cursor = next;
      }

      // Now step day-by-day (by interval) through the target month,
      // collecting any date that falls inside it.
      while (cursor <= targetEnd) {
        if (cursor >= targetStart) {
          dates.push(cursor.toISOString().split('T')[0]);
        }
        cursor.setDate(cursor.getDate() + intervalDays);
      }
    } else {
      // The anchor date is AFTER the target month — step BACKWARD instead.
      let cursor = new Date(anchor);
      while (cursor > targetEnd) {
        cursor.setDate(cursor.getDate() - intervalDays);
      }
      while (cursor >= targetStart) {
        if (cursor <= targetEnd) dates.push(cursor.toISOString().split('T')[0]);
        cursor.setDate(cursor.getDate() - intervalDays);
      }
      dates.reverse(); // put them back in chronological order
    }

    return dates;
  }

  // ---- AVERAGE MODE (fallback / default) ----
  // Use the classic "paychecks per year / 12" average.
  // weekly: 52/12 = 4.33   |   biweekly: 26/12 = 2.17
  // We return a placeholder array of that LENGTH (rounded) so that
  // code which does `.length` on the result still works sensibly.
  const avgCount = state.incomeFreq === 'weekly' ? 4.33 : 2.17;
  return new Array(Math.round(avgCount)).fill(`${year}-${String(month + 1).padStart(2, '0')}-01`);
}

// Returns the TOTAL income for a given month, taking the pay schedule into account.
// This is the number used everywhere "monthly income" matters
// (available balance, daily budget, etc.)
function getMonthlyIncome(year, month) {
  // Monthly salary: the amount entered IS the monthly amount.
  if (state.incomeFreq === 'monthly') return state.income;

  // Average mode: paycheck amount × average paychecks-per-month.
  if (state.payMode === 'average') {
    const avgCount = state.incomeFreq === 'weekly' ? 4.33 : 2.17;
    return state.income * avgCount;
  }

  // Pattern or manual mode: paycheck amount × ACTUAL number of paydates this month.
  const payDates = getPayDatesInMonth(year, month);
  return state.income * payDates.length;
}

// Daily budget = (this month's income minus fixed bills) ÷ number of days in the month.
// This is the number shown on the Calendar to decide if a day is "green" or "red".
function getDailyBudget(year, month) {
  const days = new Date(year, month + 1, 0).getDate(); // last day-of-month = total days
  const fixed = state.expenses.reduce((s, e) => s + e.amt, 0);
  const income = getMonthlyIncome(year, month);
  return income > 0 ? (income - fixed) / days : 0;
}
