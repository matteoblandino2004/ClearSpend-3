// ============================================================
// ClearSpend — cards.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   7. CARDS SCREEN
   ================================================================ */

// Redraws the grid of card tiles, each showing utilization, APR, due date, etc.
function renderCards() {
  const el = document.getElementById('c-list');
  if (state.cards.length === 0) {
    el.innerHTML = '<p class="empty-state">No cards added yet</p>';
    return;
  }

  el.innerHTML = '<div class="cards-grid">' + state.cards.map(c => {
    // Total owed = whatever balance the user entered manually + all purchases logged to this card
    const spent = state.purchases.filter(p => p.cardId === c.id).reduce((s, p) => s + p.amt, 0);
    const totalOwed = c.balance + spent;

    const pct = c.limit > 0 ? Math.min(100, totalOwed / c.limit * 100) : 0;
    const fillColor = pct > 70 ? 'red' : pct > 40 ? 'amber' : 'green';

    // Figure out how many days until the next due date (rolls over to next month if past)
    const today = new Date();
    let daysUntilDue = '';
    if (c.due) {
      const due = new Date(today.getFullYear(), today.getMonth(), c.due);
      if (due < today) due.setMonth(due.getMonth() + 1); // already passed this month -> next month
      const diff = Math.ceil((due - today) / (1000 * 60 * 60 * 24));
      daysUntilDue = diff <= 7
        ? `<span class="badge" style="color:var(--red)">${diff} days until due</span>`
        : `<span class="badge">Due in ${diff} days</span>`;
    }

    return `
      <div class="card" style="margin-bottom:0">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
          <div style="display:flex;align-items:center;gap:10px">${getNetTag(c.type)}<span style="font-size:16px;font-weight:700">${c.name}</span></div>
          <button class="btn-danger" onclick="removeCard(${c.id})">×</button>
        </div>
        ${c.limit > 0 ? `
          <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text2);margin-bottom:4px">
            <span>Spent: <strong style="color:var(--text)">${fmt(totalOwed)}</strong></span>
            <span>Limit: ${fmt(c.limit)}</span>
          </div>
          <div class="prog-bar"><div class="prog-fill ${fillColor}" style="width:${pct.toFixed(1)}%"></div></div>
          <div class="badge-row">
            <span class="badge">${pct.toFixed(0)}% utilized</span>
            ${c.apr ? `<span class="badge">${c.apr}% APR</span>` : ''}
            ${daysUntilDue}
          </div>` : `<div style="font-size:13px;color:var(--text3)">Debit / no limit set</div>`}
      </div>`;
  }).join('') + '</div>';
}

// Adds a new card from the "Add a card" form.
function addCard() {
  const name = document.getElementById('c-name').value.trim();
  if (!name) { alert('Please enter a card name.'); return; }

  state.cards.push({
    name,
    type: document.getElementById('c-type').value,
    limit: parseFloat(document.getElementById('c-limit').value) || 0,
    apr: parseFloat(document.getElementById('c-apr').value) || 0,
    due: parseInt(document.getElementById('c-due').value) || 0,
    balance: parseFloat(document.getElementById('c-bal').value) || 0,
    id: Date.now()
  });

  // Clear the form
  ['c-name','c-limit','c-apr','c-due','c-bal'].forEach(id => document.getElementById(id).value = '');

  saveState();
  renderCards();
  updateCardDropdown(); // new card should now appear when logging a purchase
}

// Removes a card by id. NOTE: purchases already logged to this card are kept
// (they remember the card's name/type at the time, see logPurchase), so your
// purchase history doesn't disappear — but it can no longer be selected for
// new purchases.
function removeCard(id) {
  state.cards = state.cards.filter(c => c.id !== id);
  saveState();
  renderCards();
  updateCardDropdown();
}
