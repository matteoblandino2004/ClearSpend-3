// ============================================================
// ClearSpend — goals.js
// Part of the ClearSpend personal finance app.
// See README.md for full documentation and file structure.
// ============================================================

/* ================================================================
   9. GOALS SCREEN
   ================================================================ */

// Redraws the list of savings goals with progress bars.
function renderGoals() {
  const el = document.getElementById('g-list');
  const sel = document.getElementById('g-sel');

  // Keep the "Select goal" dropdown (used for adding funds) in sync
  if (sel) {
    sel.innerHTML = state.goals.length === 0
      ? '<option value="">No goals added yet</option>'
      : state.goals.map(g => `<option value="${g.id}">${g.name}</option>`).join('');
  }

  if (state.goals.length === 0) {
    el.innerHTML = '<p class="empty-state">No goals yet. Add one to start saving!</p>';
    return;
  }

  el.innerHTML = state.goals.map(g => {
    const pct = Math.min(100, g.saved / g.target * 100);
    const left = g.target - g.saved;

    let dateInfo = '';
    if (g.date) {
      const dd = Math.ceil((new Date(g.date + 'T00:00:00') - new Date()) / (1000 * 60 * 60 * 24));
      if (dd > 0) {
        const now = new Date();
        const monthlyIncome = getMonthlyIncome(now.getFullYear(), now.getMonth());
        // Rough estimate of $/month needed to hit the goal by the target date
        const needed = monthlyIncome > 0 ? (left / (dd / 30)).toFixed(0) : null;
        dateInfo = `<span class="badge">${dd} days left${needed ? ' · need ~$' + needed + '/mo' : ''}</span>`;
      } else {
        dateInfo = `<span class="badge" style="color:var(--red)">Past due</span>`;
      }
    }

    return `
      <div class="goal-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <span class="goal-name">${g.name}</span>
          <button class="btn-danger" onclick="removeGoal(${g.id})">×</button>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--text2);margin-bottom:4px">
          <span>${fmt(g.saved)} saved</span><span>${fmt(g.target)} goal</span>
        </div>
        <div class="prog-bar"><div class="prog-fill green" style="width:${pct.toFixed(1)}%"></div></div>
        <div class="badge-row"><span class="badge">${pct.toFixed(0)}% complete</span><span class="badge">${fmt(left)} to go</span>${dateInfo}</div>
      </div>`;
  }).join('');
}

// Adds a new savings goal.
function addGoal() {
  const name = document.getElementById('g-name').value.trim();
  const target = parseFloat(document.getElementById('g-target').value) || 0;
  if (!name || !target) { alert('Please enter a goal name and target amount.'); return; }

  state.goals.push({
    name,
    target,
    saved: parseFloat(document.getElementById('g-saved').value) || 0,
    date: document.getElementById('g-date').value || '',
    id: Date.now()
  });

  ['g-name','g-target','g-saved','g-date'].forEach(id => document.getElementById(id).value = '');
  saveState();
  renderGoals();
}

// Removes a goal by id.
function removeGoal(id) {
  state.goals = state.goals.filter(g => g.id !== id);
  saveState();
  renderGoals();
}

// Adds money to whichever goal is selected in the dropdown (capped at the target).
function addToGoal() {
  const id = parseInt(document.getElementById('g-sel').value);
  const amt = parseFloat(document.getElementById('g-add-amt').value) || 0;
  if (!id || !amt) return;

  const g = state.goals.find(x => x.id === id);
  if (g) {
    g.saved = Math.min(g.target, g.saved + amt); // never exceed the target
    document.getElementById('g-add-amt').value = '';
    saveState();
    renderGoals();
  }
}
